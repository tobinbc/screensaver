/**
 * Manage Google Analytics tracking
 *
 * @module scripts/my_analytics
 */
import * as ChromeGA from '../node_modules/chrome-ext-utils/src/analytics.js';
import * as ChromeUtils from '../node_modules/chrome-ext-utils/src/utils.js';
/** Tracking ID */

const TRACKING_ID = 'UA-61314754-1';
/** Event types specific to this extension */

export const EVENT = {
  /** Load list of Google Photos albums */
  LOAD_ALBUM_LIST: {
    eventCategory: 'googlePhotosAPI',
    eventAction: 'loadAlbumList',
    eventLabel: ''
  },

  /** User selected an album */
  SELECT_ALBUM: {
    eventCategory: 'googlePhotosAPI',
    eventAction: 'selectAlbum',
    eventLabel: ''
  },

  /** Load a Google Photos album */
  LOAD_ALBUM: {
    eventCategory: 'googlePhotosAPI',
    eventAction: 'loadAlbum',
    eventLabel: ''
  },

  /** Load a group of Google Photos photos */
  LOAD_PHOTOS: {
    eventCategory: 'googlePhotosAPI',
    eventAction: 'loadPhotos',
    eventLabel: ''
  },

  /** Load the Google Photos for the photos-view UI */
  LOAD_FILTERED_PHOTOS: {
    eventCategory: 'googlePhotosAPI',
    eventAction: 'loadFilteredPhotos',
    eventLabel: ''
  },

  /** Update the saved Google Photos albums */
  FETCH_ALBUMS: {
    eventCategory: 'googlePhotosAPI',
    eventAction: 'fetchAlbums',
    eventLabel: ''
  },

  /** Update the saved Google Photos photos */
  FETCH_PHOTOS: {
    eventCategory: 'googlePhotosAPI',
    eventAction: 'fetchPhotos',
    eventLabel: ''
  },

  /** Limited number of photos loaded in a Google Photos album */
  PHOTOS_LIMITED: {
    eventCategory: 'googlePhotosAPI',
    eventAction: 'limitedAlbumPhotos',
    eventLabel: ''
  },

  /** Limited number of Google Photos albums loaded during list albums */
  ALBUMS_LIMITED: {
    eventCategory: 'googlePhotosAPI',
    eventAction: 'limitedAlbums',
    eventLabel: ''
  },

  /** Limited the total number of Google Photos loaded */
  PHOTO_SELECTIONS_LIMITED: {
    eventCategory: 'googlePhotosAPI',
    eventAction: 'limitedTotalPhotos',
    eventLabel: ''
  },

  /** View the original source of a photo in a new tab */
  VIEW_PHOTO: {
    eventCategory: 'ui',
    eventAction: 'viewPhoto',
    eventLabel: ''
  },

  /** Current weather updated */
  WEATHER_UPDATED: {
    eventCategory: 'weather',
    eventAction: 'updatedWeather',
    eventLabel: ''
  }
};
/** Initialize analytics */

export function initialize() {
  ChromeGA.initialize(TRACKING_ID, 'Photo Screensaver', 'screensaver', ChromeUtils.getVersion());
}