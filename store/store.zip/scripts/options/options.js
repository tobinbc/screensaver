/**
 * Manage the options UI
 *
 * @module scripts/options
 */
import '../../elements/app-main/app-main.js';
/**
 * The options UI instance
 *
 * @remarks
 * This allows us to get a reference
 */

export let Options; // listen for document and resources loaded

window.addEventListener('load', () => {
  // @ts-ignore
  // TODO Anything we can do here?
  Options = document.querySelector('app-main');
});