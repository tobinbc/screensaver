/**
 * Chrome messages specific to this app
 *
 * @module scripts/my_msg
 */

/** Chrome Messages specific to this extension */
export const TYPE = {
  /** Show screensaver */
  SS_SHOW: {
    message: 'showScreensaver'
  },

  /** Close screensaver */
  SS_CLOSE: {
    message: 'closeScreensaver'
  },

  /** Is a screensaver showing */
  SS_IS_SHOWING: {
    message: 'isScreensaverShowing'
  },

  /** Failed to retrieve a {@link PhotoSource} */
  PHOTO_SOURCE_FAILED: {
    message: 'photoSourceFailed',
    key: '',
    error: ''
  },

  /** Request to load the filtered google photos */
  LOAD_FILTERED_PHOTOS: {
    message: 'loadFilteredPhotos'
  },

  /** Number of photos loaded so far */
  FILTERED_PHOTOS_COUNT: {
    message: 'filteredPhotosCount',
    count: 0
  },

  /** Request to load all the saved albums */
  LOAD_ALBUMS: {
    message: 'loadAlbums'
  },

  /** Request to load an album */
  LOAD_ALBUM: {
    message: 'loadAlbum'
  },

  /** Number of photos loaded for an album so far */
  ALBUM_COUNT: {
    message: 'albumCount',
    count: 0
  },

  /** Update the alarm for getting the current weather */
  UPDATE_WEATHER_ALARM: {
    message: 'updateWeatherAlarm'
  },

  /** Update the current weather */
  UPDATE_WEATHER: {
    message: 'updateWeather'
  }
};