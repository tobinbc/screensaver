/**
 * A source of photos from Chromecast
 *
 * @module scripts/sources/photo_source_chromecast
 */

/** */

/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */
import * as ChromeHttp from '../../node_modules/chrome-ext-utils/src/http.js';
import * as ChromeJSON from '../../node_modules/chrome-ext-utils/src/json.js';
import { PhotoSource } from './photo_source.js';
/** A source of photos from Chromecast */

export class CCSource extends PhotoSource {
  constructor(useKey, photosKey, type, desc, isLimited, isDaily, isArray, loadArg) {
    super(useKey, photosKey, type, desc, isLimited, isDaily, isArray, loadArg);
  }
  /**
   * Fetch the photos for this source
   *
   * @throws An error if fetch failed
   * @returns Array of {@link IPhoto}
   */


  async fetchPhotos() {
    const url = '/assets/chromecast.json'; // no need to check for internet connection since our call is local

    const conf = ChromeJSON.shallowCopy(ChromeHttp.CONFIG);
    conf.checkConnection = false;
    let photos = await ChromeHttp.doGet(url, conf);
    photos = photos || [];

    for (const photo of photos) {
      photo.asp = '1.78';
    }

    return photos;
  }

}