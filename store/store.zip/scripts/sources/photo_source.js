/**
 * Module for classes that provide photos to the screensaver
 *
 * @module scripts/sources/photo_source
 */
import * as ChromeLocale from '../../node_modules/chrome-ext-utils/src/locales.js';
import * as ChromeLog from '../../node_modules/chrome-ext-utils/src/log.js';
import * as ChromeStorage from '../../node_modules/chrome-ext-utils/src/storage.js';
import * as ChromeUtils from '../../node_modules/chrome-ext-utils/src/utils.js';
/** Base class for a source of photos for a {@link Screensaver} */

export class PhotoSource {
  /**
   * Add a {@link IPhoto} to an existing Array
   *
   * @param photos - The array to add to
   * @param url - The url to the photo
   * @param author - The photographer
   * @param asp - The aspect ratio of the photo
   * @param ex - Additional information about the photo
   * @param point - An optional geolocation
   */
  static addPhoto(photos, url, author, asp, ex, point = '') {
    const photo = {
      url: url,
      author: author,
      asp: asp.toPrecision(3)
    };

    if (ex) {
      photo.ex = ex;
    }

    if (point && !ChromeUtils.isWhiteSpace(point)) {
      photo.point = point;
    }

    photos.push(photo);
  }
  /**
   * Create a geo point string from a latitude and longitude
   *
   * @param lat - latitude
   * @param lon - longitude
   * @returns 'lat lon'
   */


  static createPoint(lat, lon) {
    return `${lat} ${lon}`;
  }
  /**
   * Create a new photo source
   *
   * @param useKey - The key for if the source is selected
   * @param photosKey - The key for the collection of photos
   * @param type - A descriptor of the photo source
   * @param desc - A human readable description of the source
   * @param isLimited - Should we limit the frequency of updates
   * @param isDaily - Should the source be updated daily
   * @param isArray - Is the source an Array of photo Arrays
   * @param loadArg - optional arg for load function
   */


  constructor(useKey, photosKey, type, desc, isLimited, isDaily, isArray, loadArg) {
    this._useKey = useKey;
    this._photosKey = photosKey;
    this._type = type;
    this._desc = desc;
    this._isLimited = isLimited;
    this._isDaily = isDaily;
    this._isArray = isArray;
    this._loadArg = loadArg;
  }
  /** Get the photos key that is persisted */


  getPhotosKey() {
    return this._photosKey;
  }
  /** Get a human readable description */


  getDesc() {
    return this._desc;
  }
  /** Get use key name */


  getUseKey() {
    return this._useKey;
  }
  /** Get extra argument */


  getLoadArg() {
    return this._loadArg;
  }
  /** Get if we should limit updates when possible */


  isLimited() {
    return this._isLimited;
  }
  /** Get if we should update daily */


  isDaily() {
    return this._isDaily;
  }
  /**
   * Get the photos from local storage
   *
   * @returns the source's photos
   */


  async getPhotos() {
    const ret = {
      type: this._type,
      photos: []
    };

    if (await this.use()) {
      let photos = [];

      if (this._isArray) {
        const items = await ChromeStorage.asyncGet(this._photosKey, []);

        for (const item of items) {
          photos = photos.concat(item.photos);
        }
      } else {
        photos = await ChromeStorage.asyncGet(this._photosKey, []);
      }

      ret.photos = photos;
    }

    return ret;
  }
  /**
   * Determine if this source has been selected for display
   *
   * @returns true if selected
   */


  async use() {
    return await ChromeStorage.asyncGet(this._useKey);
  }
  /**
   * Process the photo source.
   *
   * @throws An error if we failed to retrieve photos
   */


  async process() {
    if (await this.use()) {
      // add the source
      try {
        const photos = await this.fetchPhotos();
        const err = await this.save(photos);

        if (err) {
          return Promise.reject(err);
        }
      } catch (err) {
        let title = ChromeLocale.localize('err_photo_source_title');
        title += `: ${this._desc}`;
        ChromeLog.error(err.message, 'PhotoSource.process', title, `source: ${this._useKey}`);
        throw err;
      }
    } else {
      // remove the source
      // HACK so we don't delete album or photos when Google Photos
      // page is disabled
      const useGoogle = await ChromeStorage.asyncGet('useGoogle', true);
      let isGoogleKey = false;

      if (this._photosKey === 'albumSelections' || this._photosKey === 'googleImages') {
        isGoogleKey = true;
      }

      if (!(isGoogleKey && !useGoogle)) {
        try {
          await chrome.storage.local.remove(this._photosKey);
        } catch (err) {// ignore
        }
      }
    }
  }
  /**
   * Save the data to chrome.storage.local in a safe manner
   *
   * @param photos - could be array of photos or albums
   * @returns An error if the save failed
   */


  async save(photos) {
    let ret;
    const keyBool = this._useKey;

    if (photos && photos.length) {
      const set = await ChromeStorage.asyncSet(this._photosKey, photos, keyBool);

      if (!set) {
        ret = new Error('Exceeded storage capacity.');
      }
    }

    return ret;
  }

}