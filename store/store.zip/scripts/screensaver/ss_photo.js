/**
 * Module for a screensaver photo
 *
 * @module scripts/ss/photo
 */
import * as ChromeGA from '../../node_modules/chrome-ext-utils/src/analytics.js';
import * as ChromeStorage from '../../node_modules/chrome-ext-utils/src/storage.js';
import * as MyGA from "../my_analytics.js";
/**
 * A photo for the screensaver
 */

export class SSPhoto {
  /**
   * Determine if a given aspect ratio should be ignored
   *
   * @param asp - an aspect ratio
   * @returns true if the aspect ratio should be ignored
   */
  static async ignore(asp) {
    let ret = false;
    const skip = await ChromeStorage.asyncGet('skip', false);
    const photoSizing = await ChromeStorage.asyncGet('photoSizing', 0);

    if (skip && (photoSizing === 1 || photoSizing === 3) && SSPhoto._isBadAspect(asp)) {
      // ignore photos that would look bad with cropped or stretched sizing options
      ret = true;
    }

    return ret;
  }
  /**
   * Determine if a photo would look bad zoomed or stretched at the given aspect ratio
   *
   * @param asp - an aspect ratio
   * @returns true if a photo aspect ratio differs substantially from the screens'
   */


  static _isBadAspect(asp) {
    const SCREEN_AR = screen.width / screen.height; // arbitrary

    const CUT_OFF = 0.5;
    return asp < SCREEN_AR - CUT_OFF || asp > SCREEN_AR + CUT_OFF;
  }
  /**
   * Create a new photo
   *
   * @param id - unique id
   * @param source - persisted source photo
   * @param sourceType - the PhotoSource type this photo is from
   */


  constructor(id, source, sourceType) {
    this._url = source.url;
    this._photographer = source.author ? source.author : '';
    this._aspectRatio = parseFloat(source.asp);
    this._ex = source.ex;
    this._point = source.point;
    this._type = sourceType;
    this._isBad = false;
  }
  /**
   * Is photo bad
   */


  isBad() {
    return this._isBad;
  }
  /**
   * Mark photo unusable
   */


  markBad() {
    this._isBad = true;
  }
  /**
   * Get photo url
   */


  getUrl() {
    return this._url;
  }
  /**
   * Set the url
   *
   * @param url to photo
   */


  setUrl(url) {
    this._url = url;
    this._isBad = false;
  }
  /**
   * Get photo source type
   */


  getType() {
    return this._type;
  }
  /**
   * Get photographer
   */


  getPhotographer() {
    return this._photographer;
  }
  /**
   * Get photo aspect ratio
   */


  getAspectRatio() {
    return this._aspectRatio;
  }
  /**
   * Get geo location point
   */


  getPoint() {
    return this._point;
  }
  /**
   * Get extra information
   */


  getEx() {
    return this._ex;
  }
  /**
   * Create a new tab with a link to the original source of the photo, if possible
   */


  showSource() {
    let url = null;

    switch (this._type) {
      case "flickr"
      /* PhotoSourceFactory.Type.FLICKR */
      :
        if (this._ex) {
          // parse photo id
          const regex = /(\/[^/]*){4}(_.*_)/;

          const id = this._url.match(regex);

          if (id) {
            url = `https://www.flickr.com/photos/${this._ex}${id[1]}`;
          }
        }

        break;

      case "reddit"
      /* PhotoSourceFactory.Type.REDDIT */
      :
        if (this._ex) {
          url = this._ex;
        }

        break;

      case "Google User"
      /* PhotoSourceFactory.Type.GOOGLE_USER */
      :
        if (this._ex && this._ex.url) {
          url = this._ex.url;
        }

        break;

      case "Unsplash"
      /* PhotoSourceFactory.Type.UNSPLASH */
      :
        if (this._ex && this._ex.url) {
          url = this._ex.url;
        }

        break;

      default:
        url = this._url;
        break;
    }

    if (url !== null) {
      ChromeGA.event(MyGA.EVENT.VIEW_PHOTO, this._type);
      chrome.tabs.create({
        url: url
      });
    }
  }

}