/**
 * Face detection in images
 *
 * @module scripts/ss/face_detect
 */

/**
 * Initialize the face api
 *
 * @throws An error if something goes wrong
 */
export function initialize() {
  // do not use await here. it does not catch errors properly
  return faceapi.loadTinyFaceDetectorModel('/assets/models').catch(err => {
    throw err;
  });
}
/**
 * Detect all the faces in an image
 *
 * @param img - image to check
 * @returns an array of detected faces
 */

export function detectAll(img) {
  // do not use await here. it does not catch errors properly
  return faceapi.detectAllFaces(img, new faceapi.TinyFaceDetectorOptions()).then(detections => {
    return detections;
  }).catch(() => {
    return [];
  });
}