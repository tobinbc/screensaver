/**
 * Manage screensaver instances
 *
 * @module scripts/ss/screensaver
 */
import '../../elements/screensaver-element/screensaver-element.js';
import * as ChromeLog from '../../node_modules/chrome-ext-utils/src/log.js';
import * as ChromeMsg from '../../node_modules/chrome-ext-utils/src/msg.js';
import * as MyMsg from "../my_msg.js";
/**
 * A screensaver instance
 *
 * @remarks
 * This allows us to get a reference for each screensaver
 */

export let Screensaver; // listen for document and resources loaded

window.addEventListener('load', () => {
  // @ts-ignore
  Screensaver = document.querySelector('screensaver-element');

  if (Screensaver) {
    Screensaver.launch().catch(() => {});
  } else {
    // bad news, close the screen savers
    ChromeLog.error('Failed to get screensaver reference', 'Screensaver.onLoad');
    ChromeMsg.send(MyMsg.TYPE.SS_CLOSE).catch(() => {});
  }
});