/**
 * Custom element for a page in an SPA app
 *
 * @module els/pages/error
 */
var __decorate = this && this.__decorate || function (decorators, target, key, desc) {
  var c = arguments.length,
      r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
      d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/** */

/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */


import { computed, customElement, listen, property } from '../../../node_modules/@polymer/decorators/lib/decorators.js';
import { html } from '../../../node_modules/@polymer/polymer/polymer-element.js';
import '../../../node_modules/@polymer/paper-button/paper-button.js';
import '../../../node_modules/@polymer/paper-checkbox/paper-checkbox.js';
import '../../../node_modules/@polymer/paper-icon-button/paper-icon-button.js';
import '../../../node_modules/@polymer/paper-item/paper-item-body.js';
import '../../../node_modules/@polymer/paper-item/paper-item.js';
import '../../../node_modules/@polymer/paper-material/paper-material.js';
import '../../../node_modules/@polymer/paper-toggle-button/paper-toggle-button.js';
import '../../../node_modules/@polymer/paper-tooltip/paper-tooltip.js';
import '../../../node_modules/@polymer/app-layout/app-toolbar/app-toolbar.js';
import { BasePageElement } from '../base-page/base-page.js';
import * as ChromeGA from '../../../node_modules/chrome-ext-utils/src/analytics.js';
import { ChromeLastError } from '../../../node_modules/chrome-ext-utils/src/last_error.js';
import * as MyUtils from '../../../scripts/my_utils.js';
/** Polymer element to display a {@link LastError} */

let ErrorPageElement = class ErrorPageElement extends BasePageElement {
  constructor() {
    super(...arguments);
    /** Last error */

    this.lastError = new ChromeLastError();
  }
  /** Stack trace */


  get stack() {
    return this.lastError.message ? this.lastError.stack : '';
  }
  /** Error title */


  get title() {
    return this.lastError.message ? this.lastError.title : '';
  }
  /**
   * Called when the element is added to a document.
   * Can be called multiple times during the lifetime of an element.
   */


  connectedCallback() {
    super.connectedCallback(); // listen for changes to chrome.storage

    chrome.storage.onChanged.addListener(this.onChromeStorageChanged.bind(this));
  }
  /**
   * Called when the element is removed from a document.
   * Can be called multiple times during the lifetime of an element.
   */


  disconnectedCallback() {
    super.disconnectedCallback(); // stop listening for changes to chrome.storage

    chrome.storage.onChanged.removeListener(this.onChromeStorageChanged.bind(this));
  }
  /**
   * Called during Polymer-specific element initialization.
   * Called once, the first time the element is attached to the document.
   */


  ready() {
    super.ready();
    setTimeout(async () => {
      try {
        // initialize lastError
        const lastError = await ChromeLastError.load();
        this.set('lastError', lastError);
      } catch (err) {
        ChromeGA.error(err.message, 'ErrorPage.ready');
      }
    }, 0);
  }
  /**
   * Email support
   *
   * @event
   */


  async onEmailTapped() {
    let body = await MyUtils.getEmailBody();
    body += `${this.lastError.title}\n\n${this.lastError.message}\n\n${this.lastError.stack}`;
    body += body + '\n\nPlease provide any additional info. on what led to the error.\n\n';
    const url = MyUtils.getEmailUrl('Last Error', body);
    ChromeGA.event(ChromeGA.EVENT.ICON, 'LastError email');
    chrome.tabs.create({
      url: url
    });
  }
  /**
   * Remove the error
   *
   * @event
   */


  onRemoveTapped() {
    ChromeLastError.reset().catch(() => {});
    ChromeGA.event(ChromeGA.EVENT.ICON, 'LastError delete');
  }
  /**
   * Item in chrome.storage changed
   *
   * @param changes - details on changes
   * @event
   */


  onChromeStorageChanged(changes) {
    for (const key of Object.keys(changes)) {
      if (key === 'lastError') {
        const change = changes[key];
        this.set('lastError', change.newValue);
        break;
      }
    }
  }

  static get template() {
    // language=HTML format=false
    return html`<style include="shared-styles iron-flex iron-flex-alignment">

  :host {
    display: block;
    position: relative;
  }

  .page-content {
    max-width: 1000px;
    height: 100%;
    margin-bottom: 16px;
  }

  #errorViewer {
    min-height: 75vh;
    white-space: pre-wrap;
    overflow: hidden;
    padding-left: 16px;
    padding-right: 16px;
    margin: 0;
  }

  .error-title {
    @apply --paper-font-title;
    padding: 0;
    margin: 0;
  }

  .error-text {
    @apply --paper-font-subhead;
    padding: 0;
    margin: 0;
  }

</style>

<paper-material elevation="1" class="page-content vertical layout">

  <!-- Tool bar -->
  <paper-material elevation="1">
    <app-toolbar class="page-toolbar">
      <div class="middle middle-container center horizontal layout flex">
        <div class="flex">[[localize('last_error_viewer_title')]]</div>
        <paper-icon-button id="email" icon="myicons:mail" disabled$="[[!lastError.message]]">
        </paper-icon-button>
        <paper-tooltip for="email" position="left" offset="0">
          [[localize('tooltip_error_email')]]
        </paper-tooltip>
        <paper-icon-button id="remove" icon="myicons:delete" disabled$="[[!lastError.message]]">
        </paper-icon-button>
        <paper-tooltip for="remove" position="left" offset="0">
          [[localize('tooltip_error_delete')]]
        </paper-tooltip>
      </div>
    </app-toolbar>
  </paper-material>

  <!-- Content -->
  <div class="body-content">
    <div id="errorViewer">
      <paper-item tabindex="-1" class="error-title">[[title]]</paper-item>
      <paper-item tabindex="-1" class="error-text">[[lastError.message]]</paper-item>
      <paper-item tabindex="-1" class="error-text">[[stack]]</paper-item>
    </div>
  </div>
</paper-material>
`;
  }

};

__decorate([property({
  type: Object
})], ErrorPageElement.prototype, "lastError", void 0);

__decorate([computed('lastError')], ErrorPageElement.prototype, "stack", null);

__decorate([computed('lastError')], ErrorPageElement.prototype, "title", null);

__decorate([listen('tap', 'email')], ErrorPageElement.prototype, "onEmailTapped", null);

__decorate([listen('tap', 'remove')], ErrorPageElement.prototype, "onRemoveTapped", null);

ErrorPageElement = __decorate([customElement('error-page')], ErrorPageElement);
export { ErrorPageElement };