/**
 * Custom element base class for a page in an SPA app
 *
 * @module els/pages/base
 */
var __decorate = this && this.__decorate || function (decorators, target, key, desc) {
  var c = arguments.length,
      r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
      d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/** */

/*
 *  Copyright (c) 2015-2019, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/screensaver/blob/master/LICENSE.md
 */


import { customElement } from '../../../node_modules/@polymer/decorators/lib/decorators.js';
import { BaseElement } from '../../../node_modules/common-custom-elements/src/base-element/base-element.js';
import * as ChromeUtils from '../../../node_modules/chrome-ext-utils/src/utils.js';
/** Polymer element base class for a SPA page */

let BasePageElement = class BasePageElement extends BaseElement {
  /** We are now the current page */
  async onEnterPage() {
    ChromeUtils.noop();
  }
  /** We are not going to be current anymore */


  async onLeavePage() {
    ChromeUtils.noop();
  }

};
BasePageElement = __decorate([customElement('base-page')], BasePageElement);
export { BasePageElement };