/**
 * @module els/pages/google_photos
 */
var __decorate = this && this.__decorate || function (decorators, target, key, desc) {
  var c = arguments.length,
      r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
      d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};

import { customElement, listen, property } from '../../../node_modules/@polymer/decorators/lib/decorators.js';
import { html } from '../../../node_modules/@polymer/polymer/polymer-element.js';
import '../../../node_modules/@polymer/iron-label/iron-label.js';
import '../../../node_modules/@polymer/paper-button/paper-button.js';
import '../../../node_modules/@polymer/paper-checkbox/paper-checkbox.js';
import '../../../node_modules/@polymer/paper-item/paper-item-body.js';
import '../../../node_modules/@polymer/paper-item/paper-item.js';
import '../../../node_modules/@polymer/paper-ripple/paper-ripple.js';
import { BaseElement } from '../../../node_modules/common-custom-elements/src/base-element/base-element.js';
import * as ChromeGA from '../../../node_modules/chrome-ext-utils/src/analytics.js';
/**
 * Polymer element to include or exclude a Google Photos category
 */

let PhotoCatElement = class PhotoCatElement extends BaseElement {
  constructor() {
    super(...arguments);
    /** Checked state */

    this.checked = false;
    /** Descriptive label */

    this.label = '';
    /** Optional group title */

    this.sectionTitle = '';
    /** Disabled state of element */

    this.disabled = false;
  }
  /**
   * checkbox tapped
   *
   * @event
   */


  onCheckedChange(ev) {
    const checked = ev.target.checked;
    ChromeGA.event(ChromeGA.EVENT.CHECK, `${this.id}: ${checked}`);
    this.fireEvent('value-changed', checked);
  }

  static get template() {
    // language=HTML format=false
    return html`<style include="shared-styles iron-flex iron-flex-alignment">
  :host {
    display: block;
    position: relative;
  }

  :host([disabled]) {
    pointer-events: none;
  }

  :host iron-label {
    display: block;
    position: relative;
    cursor: pointer;
  }

</style>

<iron-label for="checkbox">
  <paper-item class="center horizontal layout" tabindex="-1">
    <paper-item class="setting-label flex">
      [[label]]
      <paper-ripple center=""></paper-ripple>
    </paper-item>
    <paper-checkbox id="checkbox" name="include" checked="{{checked}}"
                    disabled$="[[disabled]]">
      [[localize('include')]]
    </paper-checkbox>
  </paper-item>
</iron-label>
`;
  }

};

__decorate([property({
  type: Boolean,
  notify: true
})], PhotoCatElement.prototype, "checked", void 0);

__decorate([property({
  type: String
})], PhotoCatElement.prototype, "label", void 0);

__decorate([property({
  type: String
})], PhotoCatElement.prototype, "sectionTitle", void 0);

__decorate([property({
  type: Boolean
})], PhotoCatElement.prototype, "disabled", void 0);

__decorate([listen('change', 'checkbox')], PhotoCatElement.prototype, "onCheckedChange", null);

PhotoCatElement = __decorate([customElement('photo-cat')], PhotoCatElement);
export { PhotoCatElement };