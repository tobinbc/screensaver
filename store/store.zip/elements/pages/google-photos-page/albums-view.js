/**
 * @module els/pages/google_photos
 */
var __decorate = this && this.__decorate || function (decorators, target, key, desc) {
  var c = arguments.length,
      r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
      d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var AlbumsViewElement_1;
import { computed, customElement, observe, property, query } from '../../../node_modules/@polymer/decorators/lib/decorators.js';
import { html } from '../../../node_modules/@polymer/polymer/polymer-element.js';
import '../../../node_modules/@polymer/iron-image/iron-image.js';
import '../../../node_modules/@polymer/iron-label/iron-label.js';
import '../../../node_modules/@polymer/iron-list/iron-list.js';
import '../../../node_modules/@polymer/paper-checkbox/paper-checkbox.js';
import '../../../node_modules/@polymer/paper-icon-button/paper-icon-button.js';
import '../../../node_modules/@polymer/paper-item/paper-item-body.js';
import '../../../node_modules/@polymer/paper-item/paper-item.js';
import '../../../node_modules/@polymer/paper-ripple/paper-ripple.js';
import '../../../node_modules/@polymer/paper-spinner/paper-spinner.js';
import '../../../node_modules/@polymer/app-storage/app-localstorage/app-localstorage-document.js';
import { BaseElement } from '../../../node_modules/common-custom-elements/src/base-element/base-element.js';
import "../../my_icons.js";
import '../../../node_modules/common-custom-elements/src/waiter-element/waiter-element.js';
import * as ChromeGA from '../../../node_modules/chrome-ext-utils/src/analytics.js';
import * as ChromeJSON from '../../../node_modules/chrome-ext-utils/src/json.js';
import * as ChromeLocale from '../../../node_modules/chrome-ext-utils/src/locales.js';
import * as ChromeLog from '../../../node_modules/chrome-ext-utils/src/log.js';
import * as ChromeMsg from '../../../node_modules/chrome-ext-utils/src/msg.js';
import * as ChromeStorage from '../../../node_modules/chrome-ext-utils/src/storage.js';
import * as MyGA from '../../../scripts/my_analytics.js';
import * as MyMsg from '../../../scripts/my_msg.js';
import { Options } from '../../../scripts/options/options.js';
import * as Permissions from '../../../scripts/permissions.js';
import { GoogleSource } from '../../../scripts/sources/photo_source_google.js';
/** Max number of albums to select */

const MAX_ALBUMS = GoogleSource.MAX_ALBUMS;
/** Max number of total photos to select */

const MAX_PHOTOS = GoogleSource.MAX_PHOTOS;
/** The array of selected albums */

let selections = [];
/**
 * Polymer element to manage Google Photos album selections
 */

let AlbumsViewElement = AlbumsViewElement_1 = class AlbumsViewElement extends BaseElement {
  constructor() {
    super(...arguments);
    /** Flag to display the loading... UI */

    this.waitForLoad = false;
    /** Status of the option permission for the Google Photos API */

    this.permPicasa = "notSet"
    /* Permissions.STATE.notSet */
    ;
    /** The array of all albums */

    this.albums = [];
    /** Flag to indicate if UI is disabled */

    this.disabled = false;
    /** Status label for waiter */

    this.waiterStatus = '';
  }
  /**
   * Fetch the photos for all the saved albums
   *
   * @returns false if we failed
   */


  static async updateSavedAlbums() {
    const METHOD = 'AlbumViews.updateSavedAlbums';

    try {
      // send message to background page to do the work
      const msg = ChromeJSON.shallowCopy(MyMsg.TYPE.LOAD_ALBUMS);
      const response = await ChromeMsg.send(msg);

      if (Array.isArray(response)) {
        // try to save
        const set = await ChromeStorage.asyncSet('albumSelections', response, 'useGoogleAlbums');

        if (!set) {
          // exceeded storage limits - use old
          selections = await ChromeStorage.asyncGet('albumSelections', []);
          Options.showStorageErrorDialog(METHOD);
          return false;
        } else {
          // update selections
          selections = response;
        }
      } else {
        // error
        const title = ChromeLocale.localize('err_status');
        const text = response.message;
        Options.showErrorDialog(title, text, METHOD);
        return false;
      }
    } catch (err) {
      // error
      const title = ChromeLocale.localize('err_status');
      const text = err.message;
      Options.showErrorDialog(title, text, METHOD);
      return false;
    }

    return true;
  }
  /**
   * Get total photo count that is currently saved
   *
   * @returns Total number of photos saved
   */


  static async getTotalPhotoCount() {
    let ct = 0;
    const albums = await ChromeStorage.asyncGet('albumSelections', []);

    for (const album of albums) {
      album.photos = album.photos || [];
      ct += album.photos.length;
    }

    return ct;
  }
  /** Hidden state of the main ui */


  get isHidden() {
    let ret = true;

    if (!this.waitForLoad && this.permPicasa === 'allowed') {
      ret = false;
    }

    return ret;
  }
  /**
   * Called when the element is added to a document.
   * Can be called multiple times during the lifetime of an element.
   */


  connectedCallback() {
    super.connectedCallback(); // listen for chrome messages

    ChromeMsg.addListener(this.onChromeMessage.bind(this));
  }
  /**
   * Called when the element is removed from a document.
   * Can be called multiple times during the lifetime of an element.
   */


  disconnectedCallback() {
    super.disconnectedCallback(); // stop listening for chrome messages

    ChromeMsg.removeListener(this.onChromeMessage.bind(this));
  }
  /**
   * Query Google Photos for the list of the users albums
   *
   * @param updatePhotos - if true, reload each selected album
   */


  async loadAlbumList(updatePhotos) {
    const METHOD = 'AlbumsView.loadAlbumList';
    const ERR_TITLE = ChromeLocale.localize('err_load_album_list');
    let albums;
    this.set('waitForLoad', true);

    try {
      const granted = await Permissions.request(Permissions.GOOGLE_PHOTOS);

      if (!granted) {
        // failed to get google photos permission
        await Permissions.removeGooglePhotos();
        const title = ERR_TITLE;
        const text = ChromeLocale.localize('err_auth_picasa');
        Options.showErrorDialog(title, text, METHOD);
        return;
      } // get the list of user's albums


      albums = await GoogleSource.loadAlbumList();
      albums = albums || [];
      this.set('albums', albums);

      if (albums.length === 0) {
        // no albums
        const text = ChromeLocale.localize('err_no_albums');
        ChromeLog.error(text, METHOD, ERR_TITLE); // fire event to let others know

        this.fireEvent('no-albums');
        return;
      }

      if (updatePhotos) {
        // update the saved selections
        await AlbumsViewElement_1.updateSavedAlbums();
      } // set selections based on those that are currently saved


      await this.selectSavedAlbums();
    } catch (err) {
      // handle errors ourselves
      const text = err.message;
      Options.showErrorDialog(ERR_TITLE, text, METHOD);
    } finally {
      this.set('waitForLoad', false);
    }
  }
  /**
   * Select as many albums as possible
   */


  async selectAllAlbums() {
    this.set('waitForLoad', true);

    try {
      for (const album of this.albums) {
        if (!album.checked) {
          this.set('albums.' + album.index + '.checked', true);
          const loaded = await this.loadAlbum(album, false);

          if (!loaded) {
            // something went wrong
            break;
          }
        }
      }
    } catch (err) {// ignore
    } finally {
      this.set('waitForLoad', false);
    }
  }
  /**
   * Remove selected albums
   */


  removeSelectedAlbums() {
    this.albums.forEach((album, index) => {
      if (album.checked) {
        this.set('albums.' + index + '.checked', false);
      }
    });
    selections = [];
    ChromeStorage.asyncSet('albumSelections', []).catch(() => {});
  }
  /**
   * Wait for load changed
   */


  waitForLoadChanged(waitForLoad, waiterStatus) {
    if (!waitForLoad) {
      this.ironList._render();

      if (waiterStatus) {
        this.set('waiterStatus', '');
      }
    }
  } // noinspection JSUnusedGlobalSymbols

  /**
   * Album checkbox state changed
   *
   * @param ev - checkbox state changed
   * @event
   */


  async onAlbumSelectChanged(ev) {
    const METHOD = 'AlbumViews.onAlbumSelectChanged';
    const album = ev.model.album;
    ChromeGA.event(ChromeGA.EVENT.CHECK, `selectGoogleAlbum: ${album.checked}`);

    try {
      if (album.checked) {
        // add new
        await this.loadAlbum(album, true);
      } else {
        // delete old
        const index = selections.findIndex(e => {
          return e.id === album.id;
        });

        if (index !== -1) {
          selections.splice(index, 1);
        }

        const set = await ChromeStorage.asyncSet('albumSelections', selections, 'useGoogleAlbums');

        if (!set) {
          // exceeded storage limits
          selections.pop();
          this.set('albums.' + album.index + '.checked', false);
          Options.showStorageErrorDialog(METHOD);
        }
      }
    } catch (err) {// ignore
    }
  }
  /**
   * Fired when a message is sent from either an extension process<br>
   * (by runtime.sendMessage) or a content script (by tabs.sendMessage).
   * {@link https://developer.chrome.com/extensions/runtime#event-onMessage}
   *
   * @param request - details for the message
   * @param sender - MessageSender object
   * @param response - function to call once after processing
   * @returns true if asynchronous
   * @event
   */


  onChromeMessage(request, sender, response) {
    if (request.message === MyMsg.TYPE.ALBUM_COUNT.message) {
      // show user status of photo loading
      const name = request.name || '';
      const count = request.count || 0;
      const msg = `${name}\n${ChromeLocale.localize('photo_count')} ${count.toString()}`;
      this.set('waiterStatus', msg);
      response({
        message: 'OK'
      });
    }

    return false;
  }
  /**
   * Load an album from the Web
   *
   * @param album - existing album to be replaced
   * @param wait - if true, handle waiter display ourselves
   * @returns true if successful
   */


  async loadAlbum(album, wait = true) {
    const METHOD = 'AlbumViews.loadAlbum';
    const ERR_TITLE = ChromeLocale.localize('err_load_album');
    let error;
    let ret = false;

    try {
      if (selections.length >= MAX_ALBUMS) {
        // reached max number of albums
        ChromeGA.event(MyGA.EVENT.ALBUMS_LIMITED, `limit: ${MAX_ALBUMS}`);
        this.set('albums.' + album.index + '.checked', false);
        const text = ChromeLocale.localize('err_max_albums');
        Options.showErrorDialog(ERR_TITLE, text, METHOD);
        return ret;
      }

      const photoCt = await AlbumsViewElement_1.getTotalPhotoCount();

      if (photoCt >= MAX_PHOTOS) {
        // reached max number of photos
        ChromeGA.event(MyGA.EVENT.PHOTO_SELECTIONS_LIMITED, `limit: ${photoCt}`);
        this.set('albums.' + album.index + '.checked', false);
        const text = ChromeLocale.localize('err_max_photos');
        Options.showErrorDialog(ERR_TITLE, text, METHOD);
        return ret;
      }

      if (wait) {
        this.set('waitForLoad', true);
      } // send message to background page to do the work


      const msg = ChromeJSON.shallowCopy(MyMsg.TYPE.LOAD_ALBUM);
      msg.id = album.id;
      msg.name = album.name;
      const response = await ChromeMsg.send(msg);

      if (response && response.photos) {
        // album loaded
        selections.push({
          id: album.id,
          name: response.name,
          photos: response.photos
        });
        ChromeGA.event(MyGA.EVENT.SELECT_ALBUM, `maxPhotos: ${album.ct}, actualPhotosLoaded: ${response.ct}`);
        const set = await ChromeStorage.asyncSet('albumSelections', selections, 'useGoogleAlbums');

        if (!set) {
          // exceeded storage limits
          selections.pop();
          this.set('albums.' + album.index + '.checked', false);
          Options.showStorageErrorDialog(METHOD);
          return ret;
        }

        this.set('albums.' + album.index + '.ct', response.ct);
      } else {
        // error loading album
        error = new Error(response.message);
        this.set('albums.' + album.index + '.checked', false);
      }
    } catch (err) {
      error = err;
    } finally {
      if (wait) {
        this.set('waitForLoad', false);
      }
    }

    if (error) {
      Options.showErrorDialog(ERR_TITLE, error.message, METHOD);
    } else {
      ret = true;
    }

    return ret;
  }
  /**
   * Set the checked state based on the currently saved albums
   */


  async selectSavedAlbums() {
    selections = await ChromeStorage.asyncGet('albumSelections', []);

    for (let i = 0; i < this.albums.length; i++) {
      for (const selection of selections) {
        if (this.albums[i].id === selection.id) {
          this.set('albums.' + i + '.checked', true);
          this.set('albums.' + i + '.ct', selection.photos.length);
          break;
        }
      }
    }
  } // noinspection JSMethodCanBeStatic,JSUnusedGlobalSymbols

  /**
   * Computed binding: Set photo count label on an album
   *
   * @param count - number of photos in album
   * @returns i18n label
   */


  computePhotoLabel(count) {
    let ret = `${count} ${ChromeLocale.localize('photos')}`;

    if (count === 1) {
      ret = `${count} ${ChromeLocale.localize('photo')}`;
    }

    return ret;
  }

  static get template() {
    // language=HTML format=false
    return html`<!--suppress CssUnresolvedCustomProperty -->
<style include="shared-styles iron-flex iron-flex-alignment">
  :host {
    display: block;
    position: relative;
  }

  :host .waiter {
    margin: 40px auto;
  }

  :host .waiter paper-item {
    @apply --paper-font-title;
    margin: 40px auto;
  }

  :host .list-note {
    height: 48px;
    @apply --paper-font-title;
    border: 1px var(--divider-color);
    border-bottom-style: solid;
    padding: 8px 16px 8px 16px;
    white-space: normal;
  }

  :host .list-item {
    position: relative;
    border: 1px var(--divider-color);
    border-bottom-style: solid;
    padding: 0 0 0 5px;
    cursor: pointer;
  }

  :host .list-item paper-item-body {
    padding-left: 10px;
  }

  :host .list-item paper-item {
    padding-right: 0;
  }

  :host .list-item iron-image {
    height: 72px;
    width: 72px;
  }

  :host .list-item[disabled] iron-image {
    opacity: .2;
  }

  :host .list-item[disabled] {
    pointer-events: none;
  }

  :host .list-item[disabled] .setting-label {
    color: var(--disabled-text-color);
  }

  :host #ironList {
    /* browser viewport height minus both toolbars and note*/
    height: calc(100vh - 193px);
  }
</style>

<waiter-element active="[[waitForLoad]]" label="[[localize('google_loading')]]"
                status-label="[[waiterStatus]]"></waiter-element>

<div class="list-container" hidden$="[[isHidden]]">
  <paper-item class="list-note">
    [[localize('google_shared_albums_note')]]
  </paper-item>

  <iron-list id="ironList" mutable-data="true" items="{{albums}}" as="album">
    <template>
      <iron-label>
        <div class="list-item" id="[[album.uid]]" disabled$="[[disabled]]">
          <paper-item class="center horizontal layout" tabindex="-1">
            <paper-checkbox iron-label-target="" checked="{{album.checked}}" on-change="onAlbumSelectChanged"
                            disabled$="[[disabled]]"></paper-checkbox>
            <paper-item-body class="flex" two-line="">
              <div class="setting-label">[[album.name]]</div>
              <div class="setting-label" secondary="">[[computePhotoLabel(album.ct)]]</div>
              <paper-ripple center=""></paper-ripple>
            </paper-item-body>
            <iron-image src="[[album.thumb]]" sizing="cover" preload="" disabled$="[[disabled]]"></iron-image>
          </paper-item>
        </div>
      </iron-label>
    </template>
  </iron-list>

  <app-localstorage-document key="permPicasa" data="{{permPicasa}}" storage="window.localStorage">
  </app-localstorage-document>

</div>

`;
  }

};

__decorate([property({
  type: Boolean
})], AlbumsViewElement.prototype, "waitForLoad", void 0);

__decorate([property({
  type: String,
  notify: true
})], AlbumsViewElement.prototype, "permPicasa", void 0);

__decorate([property({
  type: Array,
  notify: true
})], AlbumsViewElement.prototype, "albums", void 0);

__decorate([property({
  type: Boolean
})], AlbumsViewElement.prototype, "disabled", void 0);

__decorate([property({
  type: Boolean
})], AlbumsViewElement.prototype, "waiterStatus", void 0);

__decorate([computed('waitForLoad', 'permPicasa')], AlbumsViewElement.prototype, "isHidden", null);

__decorate([query('#ironList')], AlbumsViewElement.prototype, "ironList", void 0);

__decorate([observe('waitForLoad', 'waiterStatus')], AlbumsViewElement.prototype, "waitForLoadChanged", null);

AlbumsViewElement = AlbumsViewElement_1 = __decorate([customElement('albums-view')], AlbumsViewElement);
export { AlbumsViewElement };